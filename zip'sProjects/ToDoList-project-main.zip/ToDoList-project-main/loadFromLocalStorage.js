loadFromLocalStorage();

function loadFromLocalStorage() {
    const str = localStorage.getItem('allMisions');

    if (str) {
        const divAllMissions = document.getElementById('addToPage');
        divAllMissions.innerHTML = str;
    };
};
