const apiKey = '548e8ea0fe729f1e263a78ea069a572f';
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather?units=metric&q=';

const searchBox = document.querySelector('.search input');
const searchBtn = document.querySelector('.search button');

const weatherIcon = document.querySelector('.weather-icon');

async function checkWeather(city) {
    const response = await fetch(apiUrl + city + `&appid=${apiKey}`);

    // הצגת שגיאת שם העיר
    if (response.status == 404) {
        document.querySelector('.error').style.display = 'block';
        document.querySelector('.weather').style.display = 'none';
        // הצגת שגיאת שם העיר

    } else {
        const data = await response.json();

        // בדיקת הנתונים שמתקבלים בקונסול
        console.log(data);
        // בדיקת הנתונים שמתקבלים בקונסול

        document.querySelector('.city').innerHTML = data.name;
        document.querySelector('.temp').innerHTML = Math.round(data.main.temp) + `°C`;
        document.querySelector('.humidity').innerHTML = data.main.humidity + ` %`;
        document.querySelector('.wind').innerHTML = data.wind.speed + ` km/h`;

        // שינוי התמונה באפליקציה
        if (data.weather[0].main == 'Clouds') {
            weatherIcon.src = './images/clouds.png'
        } else if (data.weather[0].main == 'Clear') {
            weatherIcon.src = './images/clear.png'
        } else if (data.weather[0].main == 'Rain') {
            weatherIcon.src = './images/rain.png'
        } else if (data.weather[0].main == 'Drizzle') {
            weatherIcon.src = './images/drizzle.png'
        } else if (data.weather[0].main == 'Mist') {
            weatherIcon.src = './images/mist.png'
        }

        // הצגת העיצוב/כל הנתונים
        document.querySelector('.weather').style.display = 'block';
        document.querySelector('.error').style.display = 'none';
        // הצגת העיצוב/כל הנתונים
    }

};

searchBtn.addEventListener('click', () => {
    checkWeather(searchBox.value);
});